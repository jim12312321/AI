"""
The template of the main script of the machine learning process
"""
import random

#python MLGame.py -f 60 -r -i rule.py arkanoid EASY 2
class MLPlay:
    def __init__(self):
        """
        Constructor
        """
        self.ball_served = False
        self.pre_ball_loc = [0,0]

    def update(self, scene_info):
        """
        Generate the command according to the received `scene_info`.
        """
        # Make the caller to invoke `reset()` for the next round.
        if (scene_info["status"] == "GAME_OVER" or
            scene_info["status"] == "GAME_PASS"):
            return "RESET"

        if not self.ball_served:
            self.ball_served = True
            command = "SERVE_TO_RIGHT"
            self.pre_ball_loc[0] = scene_info["ball"][0]
            self.pre_ball_loc[1] = scene_info["ball"][1]
            self.pre_platform = scene_info["platform"][0]
        else:
            
            p = self.predict(scene_info)
            if p == 1 :
                command = "MOVE_RIGHT"
            elif p == 2:
                command = "MOVE_LEFT"
            else:
                command = "NONE"

        return command

    def reset(self):
        """
        Reset the status
        """
        self.ball_served = False
        
    
    def predict(self,scene_info):
        """
        1：向量朝下，且向右
        2：向量朝下，且向左
        """
        
        v_x = scene_info["ball"][0] - self.pre_ball_loc[0]
        v_y = scene_info["ball"][1] - self.pre_ball_loc[1]
        self.pre_ball_loc[0] = scene_info["ball"][0]
        self.pre_ball_loc[1] = scene_info["ball"][1]
        
        
        if v_y > 0 :
            m = v_y/v_x
            predict_x = (390-scene_info["ball"][1])/m + scene_info["ball"][0]

            while(predict_x < 5 or predict_x > 195):
                if predict_x < 5:
                    delta = 5 - predict_x
                    predict_x += 2*delta
                else:
                    delta = predict_x - 195
                    predict_x -= 2*delta
            
            delta_predict = 10
            
            if predict_x - delta_predict <  scene_info["platform"][0] and scene_info["platform"][0]  < predict_x:
                return 0
            elif scene_info["platform"][0]  < predict_x  - delta_predict:
                return 1
            else:
                return 2
            
            
        else:
            if v_x > 0:
                return 1
            else:
                return 2
        
        