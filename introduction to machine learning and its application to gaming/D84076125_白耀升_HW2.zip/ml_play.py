"""
The template of the main script of the machine learning process
"""
import os
import pickle
import random
import numpy as np

# python MLGame.py -i ml_play.py pingpong HARD

class MLPlay:
    def __init__(self,side):
        """
        Constructor
        """
        self.ball_served = False
        self.previous_ball = (0, 0)
        self.side = side
        if self.side=='1P':
            file_name = './pickle/my_model_1P.pickle'
        else:
            file_name = './pickle/my_model_2P.pickle'
        with open(os.path.join(os.path.dirname(__file__), file_name), 'rb') as f:
            self.model = pickle.load(f)
    def update(self, scene_info):
        """
        Generate the command according to the received `scene_info`.
        """
        # Make the caller to invoke `reset()` for the next round.
        if scene_info["status"] != "GAME_ALIVE":
            print(scene_info["ball_speed"])
            return "RESET"

        if not self.ball_served:
            self.ball_served = True
            command = "SERVE_TO_RIGHT"
        else:
            Ball_x = scene_info["ball"][0]
            Ball_y = scene_info["ball"][1]
            Ball_speed_x = scene_info["ball_speed"][0]
            Ball_speed_y = scene_info["ball_speed"][1]
            if self.side == '1P':
                Platform = scene_info["platform_1P"][0]
            else:
                Platform = scene_info["platform_2P"][0]
            if Ball_speed_x > 0:
                if Ball_speed_y > 0:
                    Direction = 0
                else:
                    Direction = 1
            else:
                if Ball_speed_y > 0:
                    Direction = 2
                else:
                    Direction = 3
   
            x = np.array([Ball_x,Ball_y, Ball_speed_x, Ball_speed_y, Direction, Platform]).reshape((1, -1))
            y = self.model.predict(x)

            if y == 1:
                command = "MOVE_LEFT"
            elif y == 2:
                command = "MOVE_RIGHT"
            else:
                command = "NONE"

        self.previous_ball = scene_info["ball"]
        return command

    def reset(self):
        """
        Reset the status
        """
        self.ball_served = False
