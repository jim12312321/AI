"""
The template of the main script of the machine learning process
"""
import random

#python MLGame.py -i rule.py pingpong HARD
class MLPlay:
    def __init__(self,side):
        """
        Constructor
        """
        self.ball_served = False
        self.side = side
        self.blocker_x = 65

    def update(self, scene_info):
        """
        Generate the command according to the received `scene_info`.
        """
        # Make the caller to invoke `reset()` for the next round.
        if scene_info["status"] != "GAME_ALIVE":
            print(scene_info["ball_speed"])
            return "RESET"

        if not self.ball_served:
            self.ball_served = True
            command = "SERVE_TO_RIGHT"
        else:
            
            p = self.predict(scene_info)
            
            if p == 1 :
                command = "MOVE_RIGHT"
            elif p == 2:
                command = "MOVE_LEFT"
            else:
                command = "NONE"

        return command

    def reset(self):
        """
        Reset the status
        """
        self.ball_served = False

    def predict_final_x(self,scene_info,broder):
        v_x = scene_info["ball_speed"][0]
        v_y = scene_info["ball_speed"][1]
        m = v_y/v_x
        
        predict_x = (broder-scene_info["ball"][1])/m + scene_info["ball"][0]

        while(predict_x < 0 or predict_x > 200):
            if predict_x <= 0:
                delta = 0 - predict_x
                predict_x += 2*delta
            else:
                delta = predict_x - 200
                predict_x -= 2*delta
        return predict_x
    def predict_x_hit_blocker(self,scene_info):
        if self.side == '1P':
            broder = 420
            predict_x = self.predict_final_x(scene_info,260)
            direction = predict_x - self.predict_final_x(scene_info,265)
            
            v_y = abs(scene_info['ball_speed'][1])
        else:
            broder = 80        
            predict_x = self.predict_final_x(scene_info,260)
            direction = predict_x - self.predict_final_x(scene_info,265) 
            v_y = -abs(scene_info['ball_speed'][1])
        if direction > 0 :
            v_x = abs(scene_info['ball_speed'][0])
        else:
            v_x = -abs(scene_info['ball_speed'][0])
        
        m = v_y/v_x    
        predict_x = (broder-scene_info["ball"][1])/m + scene_info["ball"][0]

        while(predict_x < 0 or predict_x > 200):
            if predict_x < 0:
                delta = 0 - predict_x
                predict_x += 2*delta
            else:
                delta = predict_x - 200
                predict_x -= 2*delta
        return predict_x
       
    
    def predict(self,scene_info): 
        v_y = scene_info["ball_speed"][1]
        
        if self.side == '1P': 
            player = "platform_1P"
            if v_y > 0:
                predict_x = self.predict_final_x(scene_info,420)
            else:
                predict_x = self.predict_x_hit_blocker(scene_info)
        else:
            player = "platform_2P"
            if v_y > 0:
                predict_x = self.predict_x_hit_blocker(scene_info)
            else:
                predict_x = self.predict_final_x(scene_info,80)
        self.blocker_x = scene_info["blocker"][0]
        if predict_x == -1:
            return 0       
           
        if scene_info[player][0]+10-3 <  predict_x and predict_x <scene_info[player][0]+10+3:
            predict = 0    
        elif scene_info[player][0]+10+3  <= predict_x:
            predict = 1   
        else:    
            predict = 2 

        return predict
        