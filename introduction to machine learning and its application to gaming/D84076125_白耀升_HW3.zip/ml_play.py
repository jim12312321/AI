'''
python MLGame.py -i ml_play.py snake
'''
import pickle
import numpy as np
import os


class MLPlay:
    def __init__(self):
        """
        Constructor
        """
        with open(os.path.join(os.path.dirname(__file__), 'my_model_snake_forest.pickle'), 'rb') as f:
            self.model = pickle.load(f)
    
    def get_state(self,scene_info):
        s = np.zeros((30,30))
        snake_body = scene_info["snake_body"]
        snake_head = scene_info["snake_head"]
        food = scene_info["food"]
        s[int(snake_head[0]/10)][int(snake_head[1]/10)] = 3
        s[int(food[0]/10)][int(food[1]/10)] = 2
        for e in snake_body:
            s[int(e[0]/10)][int(e[1]/10)] = 1  
        return s
   
    def transform_state(self,s):
        return_s = []
        snake_body = []
        for i in range(s.shape[0]):
            for j in range(s.shape[1]):
                if s[i][j] == 1:
                    snake_body.append((i,j))
                elif s[i][j] == 2:
                    food = (i,j)
                elif s[i][j] == 3:
                    snake_head = (i,j)
        return_s.append(snake_head[0] > food[0])
        return_s.append(snake_head[0] < food[0])
        return_s.append(snake_head[1] > food[1])
        return_s.append(snake_head[1] < food[1])
        return tuple(return_s)
    
    def danger_sensor(self,snake_head,snake_body,direct):
        if direct == 0:
            for i in range(10,snake_head[1],10):
                if (snake_head[0],snake_head[1]-i) in snake_body:
                    return i
            return 500
        elif direct == 1:
            for i in range(10,300-snake_head[1],10):
                if (snake_head[0],snake_head[1]+i) in snake_body:
                    return i
            return 500
        elif direct == 2:
            for i in range(10,snake_head[0],10):
                if (snake_head[0]-i,snake_head[1]) in snake_body:
                    return i
            return 500
        else:
            for i in range(10,300-snake_head[0],10):
                if (snake_head[0]+i,snake_head[1]) in snake_body:
                    return i
            return 500
    def safe_a(self,snake_head,snake_body):
        safe_a = [True,True,True,True]
        #UP
        if snake_head[1]-10 < 0 or (snake_head[0],snake_head[1]-10) in snake_body:
            safe_a[0] = False
        #DOWN
        if snake_head[1]+10 >= 300 or (snake_head[0],snake_head[1]+10) in snake_body:
            safe_a[1] = False
        #LEFT
        if snake_head[0]-10 < 0 or (snake_head[0]-10,snake_head[1]) in snake_body:
            safe_a[2] = False
        #RIGHT
        if snake_head[0]+10 >= 300 or (snake_head[0]+10,snake_head[1]) in snake_body:
            safe_a[3] = False 

        sensor = [-1,-1,-1,-1]
        for i in range(len(safe_a)):
            if safe_a[i]:
                sensor[i] = self.danger_sensor(snake_head,snake_body,i)
        for i in range(len(sensor)):
            if sensor[i] < max(sensor):
                safe_a[i] = False
        return safe_a
    def update(self, scene_info):
        """
        Generate the command according to the received scene information
        """
        if scene_info["status"] == "GAME_OVER":
            return "RESET"
        s = self.get_state(scene_info)
        snake_head_x = scene_info['snake_head'][0]
        snake_head_y = scene_info['snake_head'][1]
        food_x = scene_info['food'][0]
        food_y = scene_info['food'][1] 
        U=1 if scene_info['snake_head'][1] > scene_info['food'][1] else 0
        D=1 if scene_info['snake_head'][1] < scene_info['food'][1] else 0
        L=1 if scene_info['snake_head'][0] > scene_info['food'][0] else 0
        R=1 if scene_info['snake_head'][0] < scene_info['food'][0]else 0
        safe_U=self.safe_a(scene_info['snake_head'],scene_info['snake_body'])[0]
        safe_D=self.safe_a(scene_info['snake_head'],scene_info['snake_body'])[1]
        safe_L=self.safe_a(scene_info['snake_head'],scene_info['snake_body'])[2]
        safe_R=self.safe_a(scene_info['snake_head'],scene_info['snake_body'])[3]

        x = np.array([U,D,L,R,safe_U,safe_D,safe_L,safe_R]).reshape(1,-1)
        a = self.model.predict(x)
        if a == 0:
            return "UP"
        elif a == 1:
            return "DOWN"
        elif a == 2:
            return "LEFT"
        elif a == 3:
            return "RIGHT"
        else:
            return "NONE"

    def reset(self):
        """
        Reset the status if needed
        """
        pass