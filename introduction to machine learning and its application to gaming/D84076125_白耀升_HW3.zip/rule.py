"""
The template of the script for playing the game in the ml mode
python MLGame.py -r -i rule.py snake
"""
import time
import random
class MLPlay:
    def __init__(self):
        """
        Constructor
        """
        pass

    def update(self, scene_info):
        """
        Generate the command according to the received scene information
        """
        if scene_info["status"] == "GAME_OVER":
            return "RESET"

        snake_head = scene_info["snake_head"]
        snake_body = scene_info["snake_body"]
        food = scene_info["food"]
        '''
        UP、DOWN、LEFT、RIGHT
        '''
        safe_a = [True,True,True,True]
        #UP
        if snake_head[1]-10 < 0 or (snake_head[0],snake_head[1]-10) in snake_body:
            safe_a[0] = False
        #DOWN
        if snake_head[1]+10 >= 300 or (snake_head[0],snake_head[1]+10) in snake_body:
            safe_a[1] = False
        #LEFT
        if snake_head[0]-10 < 0 or (snake_head[0]-10,snake_head[1]) in snake_body:
            safe_a[2] = False
        #RIGHT
        if snake_head[0]+10 >= 300 or (snake_head[0]+10,snake_head[1]) in snake_body:
            safe_a[3] = False 

        sensor = [-1,-1,-1,-1]
        for i in range(len(safe_a)):
            if safe_a[i]:
                sensor[i] = self.danger_sensor(snake_head,snake_body,i)
        for i in range(len(sensor)):
            if sensor[i] < max(sensor):
                safe_a[i] = False

        if snake_head[0] > food[0]:
            if safe_a[2]:
                return "LEFT"
            else:
                return self.random_safe_a(safe_a)
        elif snake_head[0] < food[0]:
            if safe_a[3]:
                return "RIGHT"
            else:
                return self.random_safe_a(safe_a)
        elif snake_head[1] > food[1]:
            if safe_a[0]:
                return "UP"
            else:
                return self.random_safe_a(safe_a)
        elif snake_head[1] < food[1]:
            if safe_a[1]:
                return "DOWN"
            else:
                return self.random_safe_a(safe_a)
        
    def random_safe_a(self,safe_a):
        sample = []
        for i in range(len(safe_a)):
            if safe_a[i]:
                sample.append(i)  
        if len(sample) == 0:
            return "NONE"
        ran = sample[0]
        if ran == 0:
            return "UP"
        elif ran == 1:
            return "DOWN"
        elif ran ==2:
            return "LEFT"
        else:
            return "RIGHT"
    def danger_sensor(self,snake_head,snake_body,dir):
        if dir == 0:
            for i in range(10,snake_head[1],10):
                if (snake_head[0],snake_head[1]-i) in snake_body:
                    return i
            return 500
        elif dir == 1:
            for i in range(10,300-snake_head[1],10):
                if (snake_head[0],snake_head[1]+i) in snake_body:
                    return i
            return 500
        elif dir == 2:
            for i in range(10,snake_head[0],10):
                if (snake_head[0]-i,snake_head[1]) in snake_body:
                    return i
            return 500
        else:
            for i in range(10,300-snake_head[0],10):
                if (snake_head[0]+i,snake_head[1]) in snake_body:
                    return i
            return 500
    def reset(self):
        """
        Reset the status if needed
        """
        pass
